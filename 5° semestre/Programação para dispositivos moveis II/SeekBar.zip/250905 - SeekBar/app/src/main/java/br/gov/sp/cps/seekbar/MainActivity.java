package br.gov.sp.cps.seekbar;

import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private SeekBar seekBarFelicidade;
    private TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        seekBarFelicidade = findViewById(R.id.seekBarFelicidade);
        textResultado = findViewById(R.id.textResultado);

        seekBarFelicidade.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                textResultado.setText("✏\uFE0F felicidade:" + i + " / " + seekBarFelicidade.getMax());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                textResultado.setText("vamos começar...");

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                textResultado.setText("\uD83D\uDE04 Sua felicidade: " + seekBarFelicidade.getProgress() +
                        "\n" + "reação: " + felicidadeCharger(seekBarFelicidade.getProgress()) +
                        "\n\uD83D\uDD12Confirmar esse valor?");
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void registrarDados(View view){
        textResultado.setText("✅ Felicidade Registrada: \nStatus: " + felicidadeCharger(seekBarFelicidade.getProgress()));
    }

    public String felicidadeCharger(int val){
        String[] reactions = {
                "Muito triste",
                "Devastado",
                "Triste",
                "Abatido",
                "Insatisfeito",
                "Indiferente",
                "Razoavelmente Satisfeito",
                "Contente",
                "feliz",
                "Muito Feliz",
                "Extremamente Feliz"};

        return  reactions[val];

    }
}