package br.gov.sp.cps.seekbarvideo;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.net.URI;

public class MainActivity extends AppCompatActivity {

    // objetos utilizados no projeto:
    private VideoView videoView;
    private SeekBar videoSeekbar;
    private TextView textTempo;
    private ImageView imgPlay, imgPause;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // vincula os objetos com os respectivos ID:
        videoSeekbar = findViewById(R.id.videoSeekBar);
        videoView = findViewById(R.id.videoView);
        textTempo = findViewById(R.id.textTempo);
        imgPlay = findViewById(R.id.imgPlay);
        imgPause = findViewById(R.id.imgPause);

        // configuração do caminho do video:
        Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.video3);
        videoView.setVideoURI(videoUri);

        // Listener para saber quando o video está preparado para reproduzir
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                videoSeekbar.setMax(videoView.getDuration());

                // inicia uma thread para atualizar o seekbar conforme o video executa
                handler.post(atualizaSeekbar);

                // inicia o video automaticamente
                videoView.start();
            }
        });

    }
    // metodo para atualizar o tempo de video e a posição da seekbar
    private Runnable atualizaSeekbar = new Runnable() {
        @Override
        public void run() {
            if (videoView.isPlaying()) {
                videoSeekbar.setProgress(videoView.getCurrentPosition());
            }
            handler.postDelayed(this, 1000);
        }
    };

    private String formataTempo(int tempo){
        int min = (tempo/1000) / 60;
        int seg = (tempo/1000) % 60;
        return String.format("%02d:%02d", min, seg);
    }

    private void atualizaTextTempo(){
        int tempoAtual = videoView.getCurrentPosition();
        int tempoTotal = videoView.getDuration();

        String tempoFormato = formataTempo(tempoAtual) + " / " + formataTempo(tempoTotal);
        textTempo.setText(tempoFormato);
    }


    public void videoPlay(View view){
        videoView.start();
    }
    public void videoPause(View view){
        videoView.pause();
    }
}